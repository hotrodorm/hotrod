package hr3.poc.aspect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrAspectPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
