package hr3.poc.model;

public interface Action {

	java.lang.Long getActionId();

	void setActionId(java.lang.Long actionId);

	java.lang.String getTitle();

	void setTitle(java.lang.String title);

	java.lang.String getSubTitle();

	void setSubTitle(java.lang.String subTitle);

}