--KZO_ACTION
insert into KZO_ACTION values (1,'Nuevo medio de comunicación de emergencias',
'En esta misma app tenemos un nuevo medio para comunicar emergencias.');

insert into KZO_ACTION values (2,'¿Cómo usar la mascarilla?',
'La mascarilla es tu mejor protección contral el Covid-19');

insert into KZO_ACTION values (3,'Cuidados para tomar en el transporte público',
'Conoce las precauciones que debes tomar durante tu recorrido.');

--KZO_RESOURCE

--KZO_NEWS
insert into KZO_NEWS values (1,'utilizan para protegerse frente al nuevo coronavirus no se puede reutilizar y debe cubrir la boca y la nariz, de manera que no quede un espacio en la cara, según se señala en la "Guía de Actuación para Personas con Condiciones de Salud Crónicas y Personas Mayores en situación de confinamiento", publicada por el Ministerio de Sanidad.', '');
insert into KZO_NEWS values (2,'Además, destaca la importancia de evitar tocar la mascarillas mientras se lleve puesta y, en el caso de hacerlo, lavarse las manos con agua y jabón; cambiarla cuando esté usada, quitársela por las cintas de la parte trasera y tirarla a un cubo de basura. Posteriormente, hay que lavarse las manos con agua y jabón.', '');
insert into KZO_NEWS values (3,'Posteriormente, hay que lavarse las manos con agua y jabón. En cuanto a las mascarillas quirúrgicas, la finalidad que tienen es evitar la transmisión de agentes infecciosos al medio ambiente procedentes de la persona que lleva. Estas son calificadas como productos sanitarios y, como tal, deben cumplir con lo establecido en la Directiva', '');